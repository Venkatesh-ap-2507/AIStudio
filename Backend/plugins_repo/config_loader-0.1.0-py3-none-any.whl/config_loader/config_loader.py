import os
import yaml
from dotenv import load_dotenv

class EnvConfigLoader:
    def __init__(self, env_path=".env"):
        self.env_path = env_path
        self.config = {}
        self.load_env()

    def load_env(self):
        load_dotenv(self.env_path)
        self.config["APP_ENV"] = os.getenv("APP_ENV", "development")
        self.config["DEBUG"] = self._to_bool(os.getenv("DEBUG", "false"))
        self.config["DB_HOST"] = os.getenv("DB_HOST", "localhost")
        self.config["DB_PORT"] = int(os.getenv("DB_PORT", 5432))
        self.config["API_KEY"] = os.getenv("API_KEY", "")

    def get(self, key, default=None):
        return self.config.get(key, default)

    def _to_bool(self, value):
        return str(value).lower() in ("1", "true", "yes", "on")


class YamlConfigLoader:
    def __init__(self, yaml_path="config.yml"):
        self.yaml_path = yaml_path
        self.config = {}
        self.load_yaml()

    def load_yaml(self):
        try:
            with open(self.yaml_path, "r") as file:
                yaml_data = yaml.safe_load(file)
                if yaml_data:
                    self.config.update(yaml_data)
        except Exception as e:
            print(f"Error loading YAML file: {e}")

    def get(self, key, default=None):
        return self.config.get(key, default)
    
if __name__ == "__main__":
    print("---- .env config ----")
    env_loader = EnvConfigLoader(".env")
    print("APP_ENV:", env_loader.get("APP_ENV"))
    print("DB_HOST:", env_loader.get("DB_HOST"))
    print("DEBUG:", env_loader.get("DEBUG"))
    print("DB_PORT:", env_loader.get("DB_PORT"))
    print("API_KEY:", env_loader.get("API_KEY"))

    print("\n---- .yml config ----")
    yaml_loader = YamlConfigLoader("config.yml")
    print("APP_NAME:", yaml_loader.get("APP_NAME"))
    print("VERSION:", yaml_loader.get("VERSION"))
    print("ENABLE_LOGGING:", yaml_loader.get("ENABLE_LOGGING"))