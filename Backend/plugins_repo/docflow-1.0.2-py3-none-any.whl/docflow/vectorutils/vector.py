import os
import uuid
import chromadb
import psycopg2
import pymongo
import snowflake.connector
from neo4j import GraphDatabase
from dotenv import load_dotenv
from typing import List, Optional
from openai import OpenAI
 
load_dotenv()
 
def get_openai_client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY is not set in the environment.")
    return OpenAI(api_key=api_key)
 
class VectorStore:
    SUPPORTED_DBS = ["chroma", "postgres", "mongo_atlas", "snowflake", "neo4j"]
 
    def __init__(self, database: str, namespace: str = "main_namespace"):
        self.database = database
        self.namespace = namespace
 
        if database == "chroma":
            self.client = chromadb.Client()
            self.collection = self.client.get_or_create_collection(name=namespace)
 
        elif database == "postgres":
            self.conn = psycopg2.connect(
                dbname=os.getenv("PG_DB"),
                user=os.getenv("PG_USER"),
                password=os.getenv("PG_PASSWORD"),
                host=os.getenv("PG_HOST", "localhost"),
                port=os.getenv("PG_PORT", "5432")
            )
            self._create_postgres_table()
 
        elif database == "mongo_atlas":
            self.mongo_client = pymongo.MongoClient(os.getenv("MONGO_ATLAS_URI"))
            self.mongo_db = self.mongo_client[os.getenv("MONGO_DB", "vector_db")]
            self.mongo_col = self.mongo_db[namespace]
 
        elif database == "snowflake":
            self.snowflake_conn = snowflake.connector.connect(
                user=os.getenv("SNOWFLAKE_USER"),
                password=os.getenv("SNOWFLAKE_PASSWORD"),
                account=os.getenv("SNOWFLAKE_ACCOUNT"),
                warehouse=os.getenv("SNOWFLAKE_WAREHOUSE"),
                database=os.getenv("SNOWFLAKE_DATABASE"),
                schema=os.getenv("SNOWFLAKE_SCHEMA")
            )
 
        elif database == "neo4j":
            self.neo4j_driver = GraphDatabase.driver(
                os.getenv("NEO4J_URI"),
                auth=(os.getenv("NEO4J_USER"), os.getenv("NEO4J_PASSWORD"))
            )
 
        else:
            raise ValueError(f"Unsupported database: {database}. Choose from: {', '.join(self.SUPPORTED_DBS)}")
 
    def _create_postgres_table(self):
        with self.conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS vectors (
                    id TEXT PRIMARY KEY,
                    namespace TEXT,
                    content TEXT,
                    embedding vector(1536)
                );
            """)
            self.conn.commit()
 
    def generate_embedding(self, text: str) -> List[float]:
        client = get_openai_client()
        response = client.embeddings.create(
            input=[text],
            model="text-embedding-ada-002"
        )
        return response.data[0].embedding
 
    def index_document(self, doc_id: str, text: str):
        embedding = self.generate_embedding(text)
        self._index([doc_id], [text], [embedding])
 
    def _index_file(self, file_path: str):
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        file_name = os.path.basename(file_path)
        doc_id = f"{os.path.splitext(file_name)[0]}_{uuid.uuid4().hex[:6]}"
        self.index_document(doc_id, content)
        print(f"Indexed file: {file_name} as ID: {doc_id}")
        return doc_id
 
    def _index(self, ids: List[str], texts: List[str], embeddings: List[List[float]]):
        if self.database == "chroma":
            self.collection.add(documents=texts, ids=ids, embeddings=embeddings)
        elif self.database == "postgres":
            with self.conn.cursor() as cur:
                for id_, text, vec in zip(ids, texts, embeddings):
                    cur.execute("""
                        INSERT INTO vectors (id, namespace, content, embedding)
                        VALUES (%s, %s, %s, %s)
                        ON CONFLICT (id) DO UPDATE
                        SET content = EXCLUDED.content,
                            embedding = EXCLUDED.embedding;
                    """, (id_, self.namespace, text, vec))
            self.conn.commit()
        elif self.database == "mongo_atlas":
            for id_, text, vec in zip(ids, texts, embeddings):
                self.mongo_col.update_one(
                    {"_id": id_},
                    {"$set": {"namespace": self.namespace, "content": text, "embedding": vec}},
                    upsert=True
                )
        elif self.database == "snowflake":
            cur = self.snowflake_conn.cursor()
            try:
                cur.execute(f"""
                    CREATE TABLE IF NOT EXISTS {self.namespace} (
                        id STRING PRIMARY KEY,
                        content STRING,
                        embedding STRING
                    )
                """)
                for id_, text, vec in zip(ids, texts, [str(e) for e in embeddings]):
                    cur.execute(f"""
                        MERGE INTO {self.namespace} t
                        USING (SELECT %s AS id, %s AS content, %s AS embedding) s
                        ON t.id = s.id
                        WHEN MATCHED THEN UPDATE SET content = s.content, embedding = s.embedding
                        WHEN NOT MATCHED THEN INSERT (id, content, embedding)
                        VALUES (s.id, s.content, s.embedding)
                    """, (id_, text, vec))
            finally:
                cur.close()
        elif self.database == "neo4j":
            with self.neo4j_driver.session() as session:
                for id_, text, vec in zip(ids, texts, embeddings):
                    session.run("""
                        MERGE (d:Document {id: $id})
                        SET d.content = $content,
                            d.namespace = $namespace,
                            d.embedding = $embedding
                    """, {"id": id_, "content": text, "namespace": self.namespace, "embedding": str(vec)})
        else:
            raise ValueError("Invalid database type.")
 
    def delete_document(self, doc_id: str):
        if not doc_id:
            return
        print(f"Deleting document with ID: {doc_id}")
        if self.database == "chroma":
            self.collection.delete(ids=[doc_id])
        elif self.database == "postgres":
            with self.conn.cursor() as cur:
                cur.execute("DELETE FROM vectors WHERE id = %s", (doc_id,))
            self.conn.commit()
        elif self.database == "mongo_atlas":
            self.mongo_col.delete_one({"_id": doc_id})
        elif self.database == "snowflake":
            cur = self.snowflake_conn.cursor()
            try:
                cur.execute(f"DELETE FROM {self.namespace} WHERE id = %s", (doc_id,))
            finally:
                cur.close()
        elif self.database == "neo4j":
            with self.neo4j_driver.session() as session:
                session.run("MATCH (d:Document {id: $id}) DETACH DELETE d", {"id": doc_id})
        else:
            raise ValueError("Invalid database type.")
 
    def query(self, query_text: str, top_k: int = 3) -> List:
        if self.database == "mongo_atlas":
            return list(self.mongo_col.find({}, {"_id": 1, "content": 1}).limit(top_k))
        return [f"{self.database} query placeholder (top_k={top_k})"]
 
def index_path(path: str, database: str, namespace: str = "main_namespace") -> Optional[str]:
    store = VectorStore(database, namespace)
    if os.path.isdir(path):
        for filename in os.listdir(path):
            full_path = os.path.join(path, filename)
            if os.path.isfile(full_path):
                try:
                    store._index_file(full_path)
                except Exception as e:
                    print(f"Skipping {filename}: {e}")
    elif os.path.isfile(path):
        return store._index_file(path)
    else:
        raise FileNotFoundError(f"Invalid path: {path}")
    print("Indexing complete.")
    return None
 
 
def vector_store_demo(
    db: str,
    path: str,
    query: str = "hello",
    top_k: int = 3,
    namespace: str = "main_namespace",
    delete_after: bool = False
):
    if db not in VectorStore.SUPPORTED_DBS:
        raise ValueError(f"Invalid database '{db}'. Choose from: {VectorStore.SUPPORTED_DBS}")
 
    store = VectorStore(db, namespace)
    doc_id = index_path(path, db, namespace)
 
    if doc_id:
        print(f"\nIndexed doc ID: {doc_id}")
        if delete_after:
            store.delete_document(doc_id)
            print(f"Deleted doc ID: {doc_id}")
 
    results = store.query(query, top_k)
    print(f"\nDB: {db}, Query: '{query}', top_k={top_k}, Results:")
    for r in results:
        print(" •", r)
