from vector import vector_store_demo

if __name__ == "__main__":
    params = {
        "db": "snowflake",
        "path": "sample_input.txt",
        "query": "hello",
        "top_k": 2,
        "delete_after": False
    }
    vector_store_demo(**params)



