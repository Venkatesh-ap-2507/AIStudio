import os
import re
import chardet
from bs4 import BeautifulSoup
from typing import Optional, Union
from charset_normalizer import from_path  # automatic encoding detector

class Cleaner:
    def __init__(self, model=None):
        """
        Initialize the Cleaner with an optional LLM model.
        """
        self.model = model

    def read_text_file(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".pdf":
            try:
                import fitz  # PyMuPDF
            except ImportError:
                raise ImportError("Install PyMuPDF: pip install pymupdf")

            with fitz.open(file_path) as doc:
                return "\n".join([page.get_text() for page in doc])

        elif ext == ".docx":
            try:
                from docx import Document
            except ImportError:
                raise ImportError("Install python-docx: pip install python-docx")

            doc = Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])

        elif ext in [".txt", ".csv", ".log"]:
            with open(file_path, "rb") as f:
                raw = f.read()
                detected = chardet.detect(raw)
                encoding = detected.get("encoding")

                if not encoding:
                    raise ValueError(f"Unable to detect encoding for: {file_path}")

                return raw.decode(encoding)

        else:
            raise ValueError(f"Unsupported file extension: {ext}")

    def write_cleaned_text(self, output_path, content):
        if not isinstance(content, str):
            content = str(content.content if hasattr(content, "content") else content)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)

    def remove_html_tags(self, text: str) -> str:
        return BeautifulSoup(text, "html.parser").get_text(separator=" ")

    def remove_special_chars(self, text: str) -> str:
        return re.sub(r"[^\w\s]", " ", text)

    def normalize_whitespace(self, text: str) -> str:
        text = text.replace("\u00a0", " ")
        return re.sub(r"\s+", " ", text).strip()

    def rule_based_cleaning(self, text: str) -> str:
        text = self.remove_html_tags(text)
        text = self.remove_special_chars(text)
        text = self.normalize_whitespace(text)
        return text

    def llm_based_cleaning(self, text: str) -> str:
        if not self.model:
            raise ValueError("LLM model must be provided for LLM-based cleaning.")
        if len(text) > 10000:
            text = text[:10000]
        return self.model.invoke(f"Clean this text and improve formatting and clarity:\n{text}")

    def clean_text_pipeline(
        self,
        input_path: Union[str, dict],
        output_path: Optional[str] = None,
        llm_cleaning: bool = False
    ) -> str:
        # Determine input type
        if isinstance(input_path, dict):
            raw_text = input_path.get("content", "")
            if not raw_text:
                raise ValueError("The input dict must contain a non-empty 'content' field.")
            file_name = input_path.get("metadata", {}).get("file_name", "cleaned_output")
        elif isinstance(input_path, str):
            if not os.path.exists(input_path):
                raise FileNotFoundError(f"File not found: {input_path}")
            raw_text = self.read_text_file(input_path)
            file_name = os.path.splitext(os.path.basename(input_path))[0]
        else:
            raise TypeError("input_path must be a file path (str) or a dict with 'content'.")

        # Apply rule-based cleaning
        cleaned_text = self.rule_based_cleaning(raw_text)

        # Optional LLM-based enhancement
        if llm_cleaning:
            cleaned_text = self.llm_based_cleaning(cleaned_text)

        # Set output path
        if not output_path:
            output_path = f"data/{file_name}_cleaned.txt"

        # Write cleaned output
        self.write_cleaned_text(output_path, cleaned_text)
        return output_path

    def clean_text_content(self, text: str, llm_cleaning: bool = False) -> str:
        cleaned_text = self.rule_based_cleaning(text)
        if llm_cleaning:
            cleaned_text = self.llm_based_cleaning(cleaned_text)
        return cleaned_text
