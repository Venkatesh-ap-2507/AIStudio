from .cleaner import TextCleaner
# Step 1: Read sample.txt
with open('sample.txt', 'r', encoding='utf-8') as f:
    sample_text = f.read()


config = {
    "language": "english",
    "steps_to_apply": [
        "remove_html_tags",
        "remove_emojis",
        "remove_accents",
        "to_lower",
        "normalize_whitespace",
        "remove_punctuation",
        "remove_special_chars",
        "remove_stopwords"
    ]
}


cleaner = TextCleaner(config=config)


cleaned_text = cleaner.clean_single(sample_text)


print("-------- Cleaned Text Output --------")
print(cleaned_text)
