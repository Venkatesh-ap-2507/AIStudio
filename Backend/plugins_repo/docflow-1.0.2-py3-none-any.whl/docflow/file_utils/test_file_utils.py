import os
from file_handler import UniversalFileHandler

BASE_DIR = "test_uploaded_files"
INPUT_DIR = os.path.join(BASE_DIR, "input_files")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

handler = UniversalFileHandler(default_dir=OUTPUT_DIR)

sample_files = [
    "sample.txt",
    "sample1.json",
    "industry.csv",
    "sample1.yaml",
    "sample.pdf",
    "technology.docx"
]

def get_file_paths():
    return [os.path.join(INPUT_DIR, f) for f in sample_files]

def run_tests():
    print("Validate Each File (default)")
    for path in get_file_paths():
        try:
            handler.validate_file(path)
            print(f" Validated: {os.path.basename(path)}")
        except Exception as e:
            print(f" Validation failed: {path}, Error: {e}")

    print("\n Validate Each File (allowed_exts, max_size_mb)")
    allowed_exts = [".txt", ".json", ".csv", ".yaml", ".pdf", ".docx"]
    for path in get_file_paths():
        try:
            handler.validate_file(path, allowed_exts=allowed_exts, max_size_mb=5)
            print(f" Validated (ext/size): {os.path.basename(path)}")
        except Exception as e:
            print(f" Validation (ext/size) failed: {path}, Error: {e}")

    print("\n Validate Files (batch)")
    results = handler.validate_files(get_file_paths(), allowed_exts=allowed_exts, max_size_mb=5)
    for r in results:
        print(f" {r['file']} -> {r['status']}")

    print("\n TEST: Read Each File")
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            print(f" Read: {os.path.basename(path)}, Lines: {result['metadata'].get('num_lines', 'N/A')}")
        except Exception as e:
            print(f" Read failed: {path}, Error: {e}")

    print("\n Read Files (batch)")
    results = handler.read_files(get_file_paths())
    for r in results:
        print(f" {r['file']} -> {r['status']}")

    print("\n Write Each File")
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            base = os.path.splitext(os.path.basename(path))[0]
            ext = os.path.splitext(path)[1].lstrip(".")
            write_ext = "txt" if ext in ["txt", "docx", "pdf", "yaml"] else ext
            output = handler.write_file(result["content"], f"{base}_copy", ext=write_ext, save_dir=OUTPUT_DIR)
            print(f" Written: {output}")
        except Exception as e:
            print(f" Write failed: {path}, Error: {e}")

    print("\n Write Files (batch)")
    data = []
    for path in get_file_paths():
        try:
            result = handler.read_file(path)
            base = os.path.splitext(os.path.basename(path))[0]
            data.append({"content": result["content"], "filename": base + "_batch"})
        except Exception as e:
            print(f" Failed to prepare for batch write: {path}, Error: {e}")
    results = handler.write_files(data, ext="txt", save_dir=OUTPUT_DIR)
    for r in results:
        print(f" {r['filename']} -> {r['status']}")

    print("\n Remove Temp File ")
    temp_path = os.path.join(OUTPUT_DIR, "temp.txt")
    with open(temp_path, "w") as f:
        f.write("delete me")
    try:
        handler.remove_file(temp_path)
        print(" Temp file removed.")
    except Exception as e:
        print(f" Remove failed: {e}")

    print("\n Upload File (Local) ")
    test_file = os.path.join(INPUT_DIR, "sample.txt")
    try:
        uploaded = handler.upload_file(test_file, storage_type="local", destination=OUTPUT_DIR)
        print(f" Uploaded locally: {uploaded}")
    except Exception as e:
        print(f" Local upload failed: {e}")

    print("\n Upload Files (Local, batch)")
    results = handler.upload_files(get_file_paths(), storage_type="local", destination=OUTPUT_DIR)
    for r in results:
        print(f" {r['file']} -> {r['status']}")

    print("\n .env Credential Access")
    provider, creds = load_credentials_from_env()
    bucket_name = os.getenv("AWS_BUCKET_NAME")
    if provider:
        print(f" Detected provider: {provider}, Credentials found.")
    else:
        print(" No provider credentials found in .env.")

    print("\n Cloud Upload Using .env ")
    remote_path = None
    if provider and creds and bucket_name:
        try:
            uploaded = handler.upload_file(test_file, storage_type="cloud", destination=bucket_name)
            print(f" Uploaded to cloud ({provider.upper()}): {uploaded}")
            remote_path = uploaded.replace("aws://", "")
        except CloudUploadError as e:
            print(f" Cloud upload failed: {e}")
        except Exception as e:
            print(f" Cloud upload failed (unexpected): {e}")
    else:
        print(" Skipping cloud upload: No credentials or bucket name.")

    print("\n Cloud Download Using .env")
    if provider and creds and remote_path:
        try:
            
            local_file = os.path.join(OUTPUT_DIR, "downloaded_" + os.path.basename(remote_path))
            downloaded = handler.download_file(provider, creds, remote_path, local_file)
            print(f" Downloaded from cloud: {downloaded}")
        except Exception as e:
            print(f" Cloud download failed: {e}")
    else:
        print(" Skipping cloud download: Upload path not found.")

if __name__ == "__main__":
    run_tests()
