import os
import json
import uuid
import boto3
import yaml
import magic
import pandas as pd
from docx import Document
from PyPDF2 import PdfReader
from google.cloud import storage as gcp_storage
from azure.storage.blob import BlobServiceClient
from pydantic import BaseModel
from typing import Optional, Any
from PIL import Image
import pytesseract
from dotenv import load_dotenv
 
load_dotenv()
 
def config_loader(key: str, default: Optional[Any] = None) -> Any:
    return os.getenv(key, default)
 
 
class CloudUploadError(Exception):
    pass
 
 
class AWSConnectionDetails(BaseModel):
    aws_access_key_id: str
    aws_secret_access_key: str
    region: str
 
 
class GCPConnectionDetails(BaseModel):
    service_account_json: str
 
 
class AzureConnectionDetails(BaseModel):
    connection_string: str
 
 
class CloudConnectionValidator:
    @staticmethod
    def validate(provider: str, conn: dict):
        if provider == "aws":
            return AWSConnectionDetails(**conn)
        elif provider == "gcp":
            return GCPConnectionDetails(**conn)
        elif provider == "azure":
            return AzureConnectionDetails(**conn)
        raise ValueError(f"Unsupported cloud provider: {provider}")
   
def load_credentials_from_env():
    """Auto-detect cloud provider and return credentials from .env in order: AWS → GCP → Azure."""
    if config_loader("AWS_ACCESS_KEY_ID") and config_loader("AWS_SECRET_ACCESS_KEY") and config_loader("AWS_REGION"):
        creds = {
            "aws_access_key_id": config_loader("AWS_ACCESS_KEY_ID"),
            "aws_secret_access_key": config_loader("AWS_SECRET_ACCESS_KEY"),
            "region": config_loader("AWS_REGION")
        }
        return "aws", creds
 
    elif config_loader("GCP_SERVICE_ACCOUNT_JSON"):
        creds = {
            "service_account_json": config_loader("GCP_SERVICE_ACCOUNT_JSON")
        }
        return "gcp", creds
 
    elif config_loader("AZURE_CONNECTION_STRING"):
        creds = {
            "connection_string": config_loader("AZURE_CONNECTION_STRING")
        }
        return "azure", creds
 
    return None, None
 
 
class UniversalFileHandler:
    def __init__(self, default_dir="uploaded_files"):
        self.default_dir = default_dir
        os.makedirs(self.default_dir, exist_ok=True)
 
    def upload_file(self, filepath, storage_type="local", destination=None, cloud_provider=None, connection_details=None):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
 
        unique_name = f"{uuid.uuid4()}_{os.path.basename(filepath)}"
 
        if storage_type == "local":
            return self._upload_to_local(filepath, destination, unique_name)
 
        elif storage_type == "cloud":
            if not cloud_provider or not connection_details:
                auto_provider, auto_creds = load_credentials_from_env()
                if auto_provider and auto_creds:
                    cloud_provider = cloud_provider or auto_provider
                    connection_details = connection_details or auto_creds
                    print(f"[INFO] Using cloud provider from .env: {cloud_provider}")
                else:
                    print("[WARN] No cloud credentials found in .env. Falling back to local upload.")
                    return self._upload_to_local(filepath, destination, unique_name)
 
            CloudConnectionValidator.validate(cloud_provider, connection_details)
            return self._upload_to_cloud(filepath, unique_name, cloud_provider.lower(), destination, connection_details)
 
        else:
            raise ValueError(f"Invalid storage type: {storage_type}")
 
 
    def upload_files(self, filepaths, storage_type="local", destination=None, cloud_provider=None, connection_details=None):
        if not isinstance(filepaths, list):
            raise TypeError("filepaths must be a list of paths")
 
        results = []
        for path in filepaths:
            try:
                uploaded = self.upload_file(path, storage_type, destination, cloud_provider, connection_details)
                results.append({"file": path, "status": "success", "uploaded_as": uploaded})
            except Exception as e:
                results.append({"file": path, "status": "failed", "error": str(e)})
        return results
 
    def _upload_to_local(self, filepath, destination, unique_name):
        target_dir = destination or self.default_dir
        os.makedirs(target_dir, exist_ok=True)
 
        original_name = os.path.basename(filepath)
        name, ext = os.path.splitext(original_name)
        version = 1
        candidate_name = f"{name}{ext}"
        candidate_path = os.path.join(target_dir, candidate_name)
 
        while os.path.exists(candidate_path):
            version += 1
            candidate_name = f"{name}_v{version}{ext}"
            candidate_path = os.path.join(target_dir, candidate_name)
 
        with open(filepath, "rb") as src, open(candidate_path, "wb") as dst:
            dst.write(src.read())
 
        print(f"[INFO] File saved as: {candidate_name}")
        return candidate_path
 
    def _upload_to_cloud(self, filepath, unique_name, cloud_provider, destination, connection_details):
        try:
            if cloud_provider == "aws":
                return self._upload_to_aws(filepath, unique_name, destination, connection_details)
            elif cloud_provider == "gcp":
                return self._upload_to_gcp(filepath, unique_name, destination, connection_details)
            elif cloud_provider == "azure":
                return self._upload_to_azure(filepath, unique_name, destination, connection_details)
            else:
                raise NotImplementedError(f"Unsupported cloud provider: {cloud_provider}")
        except Exception as e:
            raise CloudUploadError(f"{cloud_provider.capitalize()} upload failed: {str(e)}")
 
    def _upload_to_aws(self, filepath, unique_name, bucket_name, connection_details):
        required_keys = ['aws_access_key_id', 'aws_secret_access_key', 'region']
        for key in required_keys:
            if not connection_details.get(key):
                raise CloudUploadError(f"Missing AWS credential: {key}. Check your .env or connection_details.")
        s3 = boto3.client(
            's3',
            aws_access_key_id=connection_details['aws_access_key_id'],
            aws_secret_access_key=connection_details['aws_secret_access_key'],
            region_name=connection_details['region']
        )
        s3.upload_file(filepath, bucket_name, unique_name)
        return f"aws://{bucket_name}/{unique_name}"
 
    def _upload_to_gcp(self, filepath, unique_name, bucket_name, connection_details):
        client = gcp_storage.Client.from_service_account_json(connection_details['service_account_json'])
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(unique_name)
        blob.upload_from_filename(filepath)
        return f"gcp://{bucket_name}/{unique_name}"
 
    def _upload_to_azure(self, filepath, unique_name, container_name, connection_details):
        blob_service_client = BlobServiceClient.from_connection_string(connection_details['connection_string'])
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=unique_name)
        with open(filepath, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
        return f"azure://{container_name}/{unique_name}"
 
    def download_file(self, cloud_provider, connection_details, remote_path, local_path):
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        try:
            CloudConnectionValidator.validate(cloud_provider, connection_details)
            if cloud_provider == "aws":
                return self._download_from_aws(remote_path, local_path, connection_details)
            elif cloud_provider == "gcp":
                return self._download_from_gcp(remote_path, local_path, connection_details)
            elif cloud_provider == "azure":
                return self._download_from_azure(remote_path, local_path, connection_details)
            else:
                raise NotImplementedError(f"Unsupported cloud provider: {cloud_provider}")
        except Exception as e:
            raise CloudUploadError(f"{cloud_provider.capitalize()} download failed: {str(e)}")
 
    def _download_from_aws(self, remote_path, local_path, connection_details):
        bucket, key = remote_path.split("/", 1)
        s3 = boto3.client(
            's3',
            aws_access_key_id=connection_details['aws_access_key_id'],
            aws_secret_access_key=connection_details['aws_secret_access_key'],
            region_name=connection_details['region']
        )
        s3.download_file(bucket, key, local_path)
        return local_path
 
    def _download_from_gcp(self, remote_path, local_path, connection_details):
        bucket_name, blob_path = remote_path.split("/", 1)
        client = gcp_storage.Client.from_service_account_json(connection_details['service_account_json'])
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        blob.download_to_filename(local_path)
        return local_path
 
    def _download_from_azure(self, remote_path, local_path, connection_details):
        container_name, blob_path = remote_path.split("/", 1)
        blob_service_client = BlobServiceClient.from_connection_string(connection_details['connection_string'])
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        with open(local_path, "wb") as f:
            f.write(blob_client.download_blob().readall())
        return local_path
 
    def validate_file(self, filepath, allowed_exts=None, max_size_mb=50):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        if allowed_exts and not filepath.lower().endswith(tuple(allowed_exts)):
            raise ValueError(f"Unsupported file type. Allowed types: {allowed_exts}")
        if os.path.getsize(filepath) > max_size_mb * 1024 * 1024:
            raise ValueError(f"File exceeds {max_size_mb} MB size limit.")
        return True
 
    def validate_files(self, filepaths, allowed_exts=None, max_size_mb=50):
        results = []
        for path in filepaths:
            try:
                self.validate_file(path, allowed_exts, max_size_mb)
                results.append({"file": path, "status": "valid"})
            except Exception as e:
                results.append({"file": path, "status": "invalid", "error": str(e)})
        return results
 
    def remove_file(self, filepath):
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
        raise FileNotFoundError(f"File not found: {filepath}")
 
    def read_file(self, filepath, encoding="utf-8"):
        try:
            mime_type = magic.from_file(filepath, mime=True)
            ext = os.path.splitext(filepath)[1].lower()
            if mime_type == "text/plain":
                if ext == ".json":
                    mime_type = "application/json"
                elif ext in [".yaml", ".yml"]:
                    mime_type = "application/x-yaml"
                elif ext == ".csv":
                    mime_type = "text/csv"
 
            print(f"[INFO] Detected MIME type: {mime_type}")
 
            if mime_type.startswith("text/plain"):
                with open(filepath, "r", encoding=encoding) as f:
                    content = f.read()
 
            elif mime_type == "application/json":
                with open(filepath, "r", encoding=encoding) as f:
                    content = json.load(f)
 
            elif mime_type in ["application/x-yaml", "text/yaml"]:
                with open(filepath, "r", encoding=encoding) as f:
                    content = yaml.safe_load(f)
 
            elif mime_type == "text/csv":
                content = pd.read_csv(filepath, encoding=encoding).to_dict(orient="records")
 
            elif mime_type in ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"]:
                doc = Document(filepath)
                content = "\n".join(p.text for p in doc.paragraphs)
 
            elif mime_type == "application/pdf":
                reader = PdfReader(filepath)
                page_texts = []
                for idx, page in enumerate(reader.pages):
                    try:
                        text = page.extract_text()
                        page_texts.append(text if text else "")
                    except Exception as e:
                        print(f"[WARN] Skipping unreadable page {idx + 1}: {e}")
                        page_texts.append(f"[PAGE {idx + 1} UNREADABLE]")
                content = "\n".join(page_texts)
 
            else:
                raise ValueError(f"Unsupported or unknown file MIME type: {mime_type}")
 
            metadata = {
                "filename": os.path.basename(filepath),
                "size_kb": round(os.path.getsize(filepath) / 1024, 2),
                "filetype": mime_type
            }
 
            if isinstance(content, str):
                metadata["num_lines"] = content.count("\n")
 
            return {"content": content, "metadata": metadata}
 
        except UnicodeDecodeError as ue:
            raise RuntimeError(f"Encoding issue reading file. Try a different encoding (e.g. ISO-8859-1): {str(ue)}")
        except Exception as e:
            raise RuntimeError(f"Failed to read file: {str(e)}")
 
    def read_files(self, filepaths, encoding="utf-8"):
        results = []
        for path in filepaths:
            try:
                data = self.read_file(path, encoding=encoding)
                results.append({"file": path, "status": "success", "data": data})
            except Exception as e:
                results.append({"file": path, "status": "failed", "error": str(e)})
        return results
 
    def write_file(self, content, filename, ext="txt", save_dir=None):
        target_dir = save_dir or self.default_dir
        os.makedirs(target_dir, exist_ok=True)
        save_path = os.path.join(target_dir, f"{filename}.{ext}")
 
        try:
            if ext == "txt":
                with open(save_path, "w", encoding="utf-8") as f:
                    if isinstance(content, str):
                        f.write(content)
                    else:
                        f.write(str(content))
            elif ext == "json":
                with open(save_path, "w", encoding="utf-8") as f:
                    json.dump(content, f, indent=2)
            elif ext == "csv":
                if isinstance(content, list):
                    pd.DataFrame(content).to_csv(save_path, index=False)
                else:
                    raise ValueError("CSV writing expects list of dicts")
            else:
                raise ValueError(f"Unsupported write format: .{ext}")
 
            return save_path
 
        except Exception as e:
            raise RuntimeError(f"Failed to write file: {str(e)}")
 
    def write_files(self, file_data_list, ext="txt", save_dir=None):
        results = []
        for file_data in file_data_list:
            try:
                path = self.write_file(
                    content=file_data["content"],
                    filename=file_data["filename"],
                    ext=ext,
                    save_dir=save_dir
                )
                results.append({
                    "filename": file_data["filename"],
                    "status": "success",
                    "saved_to": path
                })
            except Exception as e:
                results.append({
                    "filename": file_data.get("filename", "unknown"),
                    "status": "failed",
                    "error": str(e)
                })
        return results
 
 