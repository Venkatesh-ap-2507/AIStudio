from typing import Any, Dict, Optional, List, Callable, Tuple
import json
import textwrap
import os
from pydantic import BaseModel, ValidationError

try:
    import redis
except ImportError:
    redis = None

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

# 1. Metadata key constants
METADATA_USER_ID = "user_id"
METADATA_SESSION_ID = "session_id"
METADATA_DOCUMENT_ID = "document_id"
METADATA_TYPE = "type"
METADATA_TEXT = "text"
METADATA_CHUNK_ID = "chunk_id"
METADATA_TIMESTAMP = "timestamp"

class BaseLLM:
    def __init__(self):
        self._cache = {}

    def _generate(self, prompt: str) -> str:
        raise NotImplementedError

    def generate(self, prompt: str) -> str:
        if prompt in self._cache:
            return self._cache[prompt]
        try:
            result = self._generate(prompt)
        except Exception as e:
            raise RuntimeError(f"LLM generate() failed: {e}")
        self._cache[prompt] = result
        return result

    def clear_cache(self):
        self._cache.clear()
    def is_ready(self) -> bool:
        return True

class OpenAILLM(BaseLLM):
    def __init__(self, api_key, model="gpt-3.5-turbo"):
        super().__init__()
        assert api_key, "api_key is required"
        self.client = OpenAI(api_key=api_key)
        self.model = model

    def _generate(self, prompt: str) -> str:
        assert isinstance(prompt, str), "Prompt must be a string"
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
            )
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"OpenAI LLM error: {e}")

    def invoke(self, prompt: str) -> str:
        return self.generate(prompt)

    def is_ready(self) -> bool:
        return self.client is not None


class GroqLLM(BaseLLM):
    def __init__(self, api_key, model="llama3-8b-8192"):
        super().__init__()
        from groq import Groq
        self.client = Groq(api_key=api_key)
        self.model = model
    def _generate(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return response.choices[0].message.content

class AnthropicLLM(BaseLLM):
    def __init__(self, api_key, model="claude-3-opus-20240229"):
        super().__init__()
        import anthropic
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model
    def _generate(self, prompt: str) -> str:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text if hasattr(response.content[0], 'text') else str(response.content[0])

class CohereLLM(BaseLLM):
    def __init__(self, api_key, model="command-r-plus"):
        super().__init__()
        import cohere
        self.client = cohere.Client(api_key)
        self.model = model
    def _generate(self, prompt: str) -> str:
        response = self.client.chat(
            model=self.model,
            message=prompt,
            temperature=0.2,
        )
        return response.text if hasattr(response, 'text') else str(response)

class GeminiLLM(BaseLLM):
    def __init__(self, api_key, model="gemini-pro"):
        super().__init__()
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self.client = genai.GenerativeModel(model)
        self.model = model
    def _generate(self, prompt: str) -> str:
        response = self.client.generate_content(prompt)
        return response.text if hasattr(response, 'text') else str(response)

class ShortTermMemory:
    def __init__(self):
        self._store: Dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        self._store[key] = value

    def get(self, key: str) -> Optional[Any]:
        return self._store.get(key)

    def clear(self) -> None:
        self._store.clear()

    def delete(self, key: str) -> None:
        if key in self._store:
            del self._store[key]

# Pydantic models for validation
class ContextInputModel(BaseModel):
    inputs: Dict[str, str]
    outputs: Dict[str, str]

class SummaryInputModel(BaseModel):
    summary: str

class EntityInputModel(BaseModel):
    entity: str
    value: Any

class BufferMemory:
    def __init__(self, buffer_size: int = 5):
        self.buffer_size = buffer_size
        self._buffer: List[Dict[str, str]] = []

    def save_context(self, inputs: Dict[str, str], outputs: Dict[str, str]) -> None:
        # Pydantic validation
        validated = ContextInputModel(inputs=inputs, outputs=outputs)
        inputs = validated.inputs
        outputs = validated.outputs
        assert isinstance(inputs, dict) and isinstance(outputs, dict), "Inputs/outputs must be dicts"
        turn = {"inputs": inputs, "outputs": outputs}
        self._buffer.append(turn)
        if len(self._buffer) > self.buffer_size:
            self._buffer.pop(0)

    def save_context_batch(self, turns: List[Tuple[Dict[str, str], Dict[str, str]]]) -> None:
        """Save multiple (inputs, outputs) pairs in one call."""
        for inputs, outputs in turns:
            self.save_context(inputs, outputs)

    def get(self) -> List[Dict[str, str]]:
        return list(self._buffer)

    def clear(self) -> None:
        self._buffer.clear()

    def delete(self, idx: int) -> None:
        if 0 <= idx < len(self._buffer):
            del self._buffer[idx]

    def is_ready(self) -> bool:
        return True

class SummaryMemory:
    def __init__(self):
        self._summary: Optional[str] = None

    def set(self, summary: str) -> None:
        validated = SummaryInputModel(summary=summary)
        self._summary = validated.summary

    def get(self) -> Optional[str]:
        return self._summary

    def update(self, new_lines: str, llm: BaseLLM) -> None:
        if llm is None:
            raise ValueError("LLM is required for summary update.")

        prompt = textwrap.dedent(f"""
            Progressively summarize the conversation based on the previous summary and the new lines of dialogue.

            Previous summary:
            {self._summary or "This is the beginning of the conversation."}

            New lines of dialogue:
            {new_lines}

            New summary:
        """)
        summary = llm.generate(prompt)
        validated = SummaryInputModel(summary=summary)
        self._summary = validated.summary

    def clear(self) -> None:
        self._summary = None

    def is_ready(self) -> bool:
        return True

class EntityMemory:
    def __init__(self):
        self._entities: Dict[str, Any] = {}

    def set(self, entity: str, value: Any) -> None:
        validated = EntityInputModel(entity=entity, value=value)
        self._entities[validated.entity] = validated.value

    def get(self, entity: str) -> Optional[Any]:
        return self._entities.get(entity)

    def all(self) -> Dict[str, Any]:
        return dict(self._entities)

    def update(self, new_lines: str, llm: BaseLLM) -> None:
        if llm is None:
            raise ValueError("LLM is required for entity update.")

        prompt = textwrap.dedent(f"""
            Extract key entities (like names, locations, topics) from the following text.
            Return ONLY a valid JSON object, and nothing else. For example: {{"person": "Aditya", "location": "Pune"}}

            Text:
            {new_lines}

            JSON Output:
        """)
        result = llm.generate(prompt)
        print("LLM raw output:", result)
        import re
        json_match = re.search(r'\{.*\}', result, re.DOTALL)
        if json_match:
            json_str = json_match.group(0)
            try:
                extracted_entities = json.loads(json_str)
                for k, v in extracted_entities.items():
                    validated = EntityInputModel(entity=k, value=v)
                    self._entities[validated.entity] = validated.value
            except (json.JSONDecodeError, TypeError):
                pass

    def clear(self) -> None:
        self._entities.clear()

    def delete(self, entity: str) -> None:
        if entity in self._entities:
            del self._entities[entity]

    def is_ready(self) -> bool:
        return True

class LongTermMemory:
    def __new__(cls, backend: str = "redis", **kwargs):
        if backend == "redis":
            return RedisLongTermMemory(**kwargs)
        elif backend == "mongodb":
            return MongoDBLongTermMemory(**kwargs)
        elif backend == "chroma":
            return ChromaLongTermMemory(**kwargs)
        elif backend == "snowflake":
            return SnowflakeLongTermMemory(**kwargs)
        else:
            raise ValueError(f"Unknown backend: {backend}")

    def is_ready(self) -> bool:
        return hasattr(self, 'vector_store') and self.vector_store.is_ready()

class RedisLongTermMemory:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        vector_dim: int = 384,
        index_name: str = "vector_index"
    ):
        if redis is None:
            raise ImportError("redis-py is required. Install with 'pip install redis'.")
        self._redis = redis.StrictRedis(host=host, port=port, db=db, password=password, decode_responses=True)
        self.vector_store = RedisVectorMemory(
            host=host, port=port, db=db, password=password, vector_dim=vector_dim, index_name=index_name
        )

    def save(self, key: str, value: Any) -> bool:
        value_json = json.dumps(value, sort_keys=True)
        existing = self._redis.get(key)
        if existing == value_json:
            return False
        self._redis.set(key, value_json)
        return True

    def load(self, key: str) -> Optional[Any]:
        value_json = self._redis.get(key)
        if value_json is not None:
            return json.loads(value_json)
        return None

    def clear(self) -> None:
        self._redis.flushdb()
        self.vector_store.clear()

    def save_vector(self, key: str, vector: List[float], metadata: Optional[dict] = None) -> None:
        if metadata is None:
            metadata = {}
        self.vector_store.add_vector(key, vector, metadata)

    def query_vector(self, query_vector: List[float], top_k: int = 5, type_filter: Optional[str] = None) -> List[Any]:
        return self.vector_store.query_vector(query_vector, top_k=top_k, type_filter=type_filter)

    def delete(self, key: str) -> None:
        self._redis.delete(key)

class MongoDBLongTermMemory:
    def __init__(self, uri: str, db_name: str = "vector_db", collection_name: str = "long_term_memory", vector_dim: int = 384, index_name: str = "vector_index"):
        try:
            from pymongo import MongoClient
        except ImportError:
            raise ImportError("pymongo is required for MongoDB backend.")
        self.client = MongoClient(uri)
        self.collection = self.client[db_name][collection_name]
        self.vector_store = MongoDBVectorMemory(uri, db_name=db_name, collection_name="vectors", vector_dim=vector_dim, index_name=index_name)

    def save(self, key: str, value: dict) -> None:
        doc = {"_id": key, **value}
        self.collection.replace_one({"_id": key}, doc, upsert=True)

    def load(self, key: str) -> Optional[dict]:
        doc = self.collection.find_one({"_id": key})
        if doc:
            doc.pop("_id", None)
            return doc
        return None

    def clear(self) -> None:
        self.collection.delete_many({})
        self.vector_store.clear()

    def save_vector(self, key: str, vector: List[float], metadata: Optional[dict] = None) -> None:
        if metadata is None:
            metadata = {}
        self.vector_store.add_vector(key, vector, metadata)

    def query_vector(self, query_vector: List[float], top_k: int = 5, type_filter: Optional[str] = None) -> List[Any]:
        return self.vector_store.query_vector(query_vector, top_k=top_k, type_filter=type_filter)

    def delete(self, key: str) -> None:
        self.collection.delete_one({"_id": key})

class ChromaLongTermMemory:
    def __init__(self, persist_directory: Optional[str] = None, collection_name: str = "long_term_memory"):
        try:
            import chromadb
        except ImportError:
            raise ImportError("chromadb is required for Chroma backend.")
        self.chromadb = chromadb
        self.client = chromadb.PersistentClient(path=persist_directory) if persist_directory else chromadb.Client()
        self.collection = self.client.get_or_create_collection(collection_name)
        self.vector_store = ChromaVectorMemory(persist_directory=persist_directory, collection_name=collection_name)

    def save(self, key: str, value: dict) -> None:
        self.collection.add(ids=[key], metadatas=[value], documents=[value.get("text", "")])

    def load(self, key: str) -> Optional[dict]:
        results = self.collection.get(ids=[key], include=["metadatas"])
        if results and results.get("metadatas") and results["metadatas"][0]:
            return results["metadatas"][0][0]
        return None

    def clear(self) -> None:
        self.collection.delete(where={})
        self.vector_store.clear()

    def save_vector(self, key: str, vector: List[float], metadata: Optional[dict] = None) -> None:
        if metadata is None:
            metadata = {}
        self.vector_store.add_vector(key, vector, metadata)

    def query_vector(self, query_vector: List[float], top_k: int = 5, type_filter: Optional[str] = None) -> List[Any]:
        return self.vector_store.query_vector(query_vector, top_k=top_k, type_filter=type_filter)

    def delete(self, key: str) -> None:
        self.collection.delete(ids=[key])

class SnowflakeLongTermMemory:
    def __init__(self, user, password, account, warehouse, database, schema, table="long_term_memory", vector_dim: int = 384):
        try:
            import snowflake.connector
        except ImportError:
            raise ImportError("snowflake-connector-python is required for Snowflake backend.")
        self.conn = snowflake.connector.connect(
            user=user, password=password, account=account, warehouse=warehouse, database=database, schema=schema
        )
        self.table = table
        self._ensure_table()
        self.vector_store = SnowflakeVectorMemory(user, password, account, warehouse, database, schema, table="vectors", vector_dim=vector_dim)
    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.table} (
                id STRING PRIMARY KEY,
                data VARIANT
            )
        """)
        cur.close()
    def save(self, key: str, value: dict) -> None:
        import json
        cur = self.conn.cursor()
        cur.execute(f"""
            MERGE INTO {self.table} t USING (SELECT %s AS id, PARSE_JSON(%s) AS data) s
            ON t.id = s.id
            WHEN MATCHED THEN UPDATE SET data = s.data
            WHEN NOT MATCHED THEN INSERT (id, data) VALUES (s.id, s.data)
        """, (key, json.dumps(value)))
        cur.close()
    def load(self, key: str) -> Optional[dict]:
        import json
        cur = self.conn.cursor()
        cur.execute(f"SELECT data FROM {self.table} WHERE id = %s", (key,))
        row = cur.fetchone()
        cur.close()
        if row and row[0]:
            if isinstance(row[0], str):
                try:
                    return json.loads(row[0])
                except Exception:
                    return None
            return row[0]
        return None
    def clear(self) -> None:
        cur = self.conn.cursor()
        cur.execute(f"DELETE FROM {self.table}")
        cur.close()
        self.vector_store.clear()
    def save_vector(self, key: str, vector: List[float], metadata: Optional[dict] = None) -> None:
        if metadata is None:
            metadata = {}
        self.vector_store.add_vector(key, vector, metadata)
    def query_vector(self, query_vector: List[float], top_k: int = 5, type_filter: Optional[str] = None) -> List[Any]:
        return self.vector_store.query_vector(query_vector, top_k=top_k, type_filter=type_filter)

    def delete(self, key: str) -> None:
        cur = self.conn.cursor()
        cur.execute(f"DELETE FROM {self.table} WHERE id = %s", (key,))
        cur.close()

class BaseVectorMemory:
    def add_vector(self, key: str, vector: List[float], metadata: dict) -> None:
        raise NotImplementedError
    def query_vector(self, vector: List[float], top_k: int = 5, type_filter: Optional[str] = None) -> List[dict]:
        raise NotImplementedError
    def clear(self) -> None:
        raise NotImplementedError
    def delete(self, key: str) -> None:
        raise NotImplementedError
    def clear_user(self, user_id: str) -> None:
        raise NotImplementedError
    def is_ready(self) -> bool:
        return True

class FaissVectorMemory(BaseVectorMemory):
    def __init__(self, dim: int, index_path: Optional[str] = None):
        try:
            import faiss
            import numpy as np
        except ImportError:
            raise ImportError("faiss and numpy are required for FAISS backend.")
        self.faiss = faiss
        self.np = np
        self.dim = dim
        self.index = faiss.IndexFlatL2(dim)
        self.keys = []
        self.metadata = []
        self.index_path = index_path
        if index_path and os.path.exists(index_path):
            self.index = faiss.read_index(index_path)
            
    def add_vector(self, key, vector, metadata):
        vec = self.np.array([vector]).astype('float32')
        self.index.add(vec)
        self.keys.append(key)
        self.metadata.append(metadata)
    def query_vector(self, vector, top_k=5, type_filter=None):
        vec = self.np.array([vector]).astype('float32')
        D, I = self.index.search(vec, top_k)
        results = []
        for idx in I[0]:
            if idx < len(self.keys):
                meta = self.metadata[idx]
                if type_filter is None or meta.get("type") == type_filter:
                    results.append({"key": self.keys[idx], "metadata": meta})
        return results
    def clear(self):
        self.index.reset()
        self.keys = []
        self.metadata = []
    def delete(self, key: str) -> None:
        try:
            idx = self.keys.index(key)
            del self.keys[idx]
            del self.metadata[idx]
        except ValueError:
            pass
    def clear_user(self, user_id: str) -> None:
        pass

class ChromaVectorMemory(BaseVectorMemory):
    def __init__(self, persist_directory: Optional[str] = None, collection_name: str = "default"):
        try:
            import chromadb
        except ImportError:
            raise ImportError("chromadb is required for Chroma backend.")
        self.chromadb = chromadb
        self.client = chromadb.PersistentClient(path=persist_directory) if persist_directory else chromadb.Client()
        self.collection = self.client.get_or_create_collection(collection_name)
    def add_vector(self, key, vector, metadata):
        self.collection.add(ids=[key], embeddings=[vector], metadatas=[metadata], documents=[metadata.get("text", "")])
    def query_vector(self, vector, top_k=5, type_filter=None):
        where_clause = {"type": type_filter} if type_filter else None
        
        results = self.collection.query(
            query_embeddings=[vector],
            n_results=top_k,
            where=where_clause,
            include=["metadatas"]
        )
        
        out = []
        if results and results.get("ids") and results.get("metadatas"):
            ids = results["ids"][0]
            metadatas = results["metadatas"][0]
            for i, meta in enumerate(metadatas):
                if i < len(ids):
                    out.append({"key": ids[i], "metadata": meta})
        return out
    def clear(self):
        self.collection.delete(where={})
    def delete(self, key: str) -> None:
        try:
            self.collection.delete(ids=[key])
        except Exception:
            pass
    def clear_user(self, user_id: str) -> None:
        pass

class RedisVectorMemory(BaseVectorMemory):
    def __init__(self, host="localhost", port=6379, db=0, password=None, vector_dim=384, index_name="vector_index"):
        try:
            import redis
            from redis.commands.search.field import VectorField, TagField, TextField
            from redis.commands.search.indexDefinition import IndexDefinition, IndexType
            from redis.commands.search.query import Query
        except ImportError:
            raise ImportError("redis-py with redisearch is required for Redis vector backend.")
        self.redis = redis
        self.r = redis.Redis(host=host, port=port, db=db, password=password, decode_responses=False)
        self.index_name = index_name
        self.vector_dim = vector_dim
        try:
            self.r.ft(index_name).info()
        except Exception:
            self.r.ft(index_name).create_index([
                VectorField("vector", "FLAT", {"TYPE": "FLOAT32", "DIM": vector_dim, "DISTANCE_METRIC": "L2"}),
                TagField("type"),
                TextField("text")
            ], definition=IndexDefinition(prefix=["doc:"]))
    def add_vector(self, key, vector, metadata):
        import numpy as np
        vec = np.array(vector, dtype=np.float32).tobytes()
        doc = {"vector": vec, "type": metadata.get("type", "unknown"), "text": metadata.get("text", "")}
        doc.update(metadata)
        self.r.hset(f"doc:{key}", mapping=doc)
    def query_vector(self, vector, top_k=5, type_filter=None):
        import numpy as np
        if type_filter:
            base_query = f"@type:{{{type_filter}}}=>[KNN {top_k} @vector $vector AS vector_score]"
        else:
            base_query = f"*=>[KNN {top_k} @vector $vector AS vector_score]"
        q = self.redis.commands.search.query.Query(base_query)\
            .sort_by("vector_score")\
            .paging(0, top_k)\
            .return_fields("type", "text", "user_input", "ai_output", "vector_score")\
            .dialect(2)
        vec = np.array(vector, dtype=np.float32).tobytes()
        results = self.r.ft(self.index_name).search(q, query_params={"vector": vec})
        out = []
        for doc in results.docs:
            meta = {
                "type": getattr(doc, "type", None),
                "text": getattr(doc, "text", None),
                "user_input": getattr(doc, "user_input", None),
                "ai_output": getattr(doc, "ai_output", None)
            }
            out.append({"key": doc.id, "metadata": meta})
        return out
    def clear(self):
        for key in self.r.scan_iter("doc:*"):
            self.r.delete(key)
    def delete(self, key: str) -> None:
        try:
            self.r.delete(f"doc:{key}")
        except Exception:
            pass
    def clear_user(self, user_id: str) -> None:
        pass

class MongoDBVectorMemory(BaseVectorMemory):
    def __init__(self, uri: str, db_name: str = "vector_db", collection_name: str = "vectors", vector_dim: int = 384, index_name: str = "vector_index"):
        try:
            from pymongo import MongoClient
        except ImportError:
            raise ImportError("pymongo is required for MongoDB backend.")
        self.client = MongoClient(uri)
        self.collection = self.client[db_name][collection_name]
        self.vector_dim = vector_dim
        self.index_name = index_name
        try:
            self.collection.create_index(
                [("vector", "vector")],
                name=index_name,
                default_language=None,
                weights=None,
            )
        except Exception as e:
            pass
    def add_vector(self, key, vector, metadata):
        doc = {"_id": key, "vector": vector, "metadata": metadata}
        self.collection.replace_one({"_id": key}, doc, upsert=True)
    def query_vector(self, vector, top_k=5, type_filter=None):
        search_query = {
            "queryVector": vector,
            "path": "vector",
            "numCandidates": 100,
            "limit": top_k,
            "index": self.index_name
        }

        if type_filter:
            search_query["filter"] = {
                "metadata.type": type_filter
            }

        pipeline = [
            {
                "$vectorSearch": search_query
            }
        ]
        results = list(self.collection.aggregate(pipeline))
        return [{"key": doc["_id"], "metadata": doc["metadata"]} for doc in results]
    def clear(self):
        self.collection.delete_many({})
    def delete(self, key: str) -> None:
        try:
            self.collection.delete_one({"_id": key})
        except Exception:
            pass
    def clear_user(self, user_id: str) -> None:
        pass

class SnowflakeVectorMemory(BaseVectorMemory):
    def __init__(self, user, password, account, warehouse, database, schema, table="vectors", vector_dim=384):
        try:
            import snowflake.connector
        except ImportError:
            raise ImportError("snowflake-connector-python is required for Snowflake backend.")
        self.conn = snowflake.connector.connect(
            user=user, password=password, account=account, warehouse=warehouse, database=database, schema=schema
        )
        self.table = table
        self.vector_dim = vector_dim
        self._ensure_table()
    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.table} (
                id STRING PRIMARY KEY,
                vector ARRAY,
                metadata VARIANT
            )
        """)
        cur.close()
    def add_vector(self, key, vector, metadata):
        import json
        cur = self.conn.cursor()
        placeholders = ','.join(['%s'] * len(vector))
        cur.execute(f"""
            MERGE INTO {self.table} t USING (SELECT %s AS id, ARRAY_CONSTRUCT({placeholders}) AS vector, PARSE_JSON(%s) AS metadata) s
            ON t.id = s.id
            WHEN MATCHED THEN UPDATE SET vector = s.vector, metadata = s.metadata
            WHEN NOT MATCHED THEN INSERT (id, vector, metadata) VALUES (s.id, s.vector, s.metadata)
        """, (key, *vector, json.dumps(metadata)))
        cur.close()
    def query_vector(self, vector, top_k=5, type_filter=None):
        cur = self.conn.cursor()
        where_clause = f"WHERE metadata:type = %s" if type_filter else ""
        query = f"""
            SELECT id, metadata
            FROM {self.table}
            {where_clause}
            LIMIT {top_k}
        """
        params = [type_filter] if type_filter else []
        cur.execute(query, params)
        rows = cur.fetchall()
        cur.close()
        return [{"key": row[0], "metadata": row[1]} for row in rows]
    def clear(self):
        cur = self.conn.cursor()
        cur.execute(f"DELETE FROM {self.table}")
        cur.close()
    def delete(self, key: str) -> None:
        try:
            cur = self.conn.cursor()
            cur.execute(f"DELETE FROM {self.table} WHERE id = %s", (key,))
            cur.close()
        except Exception:
            pass
    def clear_user(self, user_id: str) -> None:
        pass

VECTOR_BACKENDS = {
    "faiss": FaissVectorMemory,
    "chroma": ChromaVectorMemory,
    "redis": RedisVectorMemory,
    "mongodb": MongoDBVectorMemory,
    "snowflake": SnowflakeVectorMemory,
}

def get_vector_memory(backend: str, **kwargs) -> BaseVectorMemory:
    if backend not in VECTOR_BACKENDS:
        raise ValueError(f"Unknown vector backend: {backend}")
    return VECTOR_BACKENDS[backend](**kwargs)

class UnifiedVectorMemory:
    def __init__(self, backend: str = "faiss", embedder: Optional[Any] = None, backend_kwargs: Optional[dict] = None, chunk_size: int = 512, chunk_overlap: int = 50):
        self.backend = backend
        self.embedder = embedder
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.vector_store = get_vector_memory(backend, **(backend_kwargs or {}))

    def add_document(self, path: str, embedder: Optional[Any] = None, chunk_size: Optional[int] = None, chunk_overlap: Optional[int] = None, metadata: Optional[dict] = None):
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided.")
        chunk_size = chunk_size or self.chunk_size
        chunk_overlap = chunk_overlap or self.chunk_overlap
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        chunks = self._chunk_text(text, chunk_size, chunk_overlap)
        for i, chunk in enumerate(chunks):
            vector = embedder.embed(chunk)
            meta = {"type": "document", "source": path, "text": chunk, "chunk_id": i}
            if metadata:
                meta.update(metadata)
            key = f"{os.path.basename(path)}_chunk_{i}"
            self.vector_store.add_vector(key, vector, meta)

    def add_conversation_turn(self, user_input: str, ai_output: str, embedder: Optional[Any] = None, timestamp: Optional[str] = None, metadata: Optional[dict] = None):
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided.")
        text = f"User: {user_input}\nAI: {ai_output}"
        vector = embedder.embed(text)
        meta = {"type": "conversation", "user_input": user_input, "ai_output": ai_output}
        if timestamp:
            meta["timestamp"] = timestamp
        if metadata:
            meta.update(metadata)
        key = f"conv_{hash(text)}"
        self.vector_store.add_vector(key, vector, meta)

    def query(self, query_text: str, embedder: Optional[Any] = None, top_k: int = 5, type_filter: Optional[str] = None) -> List[dict]:
        embedder = embedder or self.embedder
        if embedder is None:
            raise ValueError("An embedder must be provided.")
        vector = embedder.embed(query_text)
        return self.vector_store.query_vector(vector, top_k=top_k, type_filter=type_filter)

    @staticmethod
    def _chunk_text(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunks.append(text[start:end])
            if end == len(text):
                break
            start += chunk_size - chunk_overlap
        return chunks

    def is_ready(self) -> bool:
        return self.vector_store.is_ready()

class MemoryManager:
    def __init__(self, llm: Optional[BaseLLM] = None, buffer_size: int = 5, long_term_backend: Optional[str] = None, vector_backend: Optional[str] = None, vector_embedder: Optional[Any] = None, vector_backend_kwargs: Optional[dict] = None, **long_term_kwargs):
        self.llm = llm
        self.short_term = ShortTermMemory()
        self.buffer = BufferMemory(buffer_size=buffer_size)
        self.summary = SummaryMemory()
        self.entity = EntityMemory()
        if long_term_backend is not None:
            self.long_term = LongTermMemory(backend=long_term_backend, **long_term_kwargs)
        else:
            self.long_term = None
        if vector_backend is not None:
            self.vector_memory = UnifiedVectorMemory(
                backend=vector_backend,
                embedder=vector_embedder,
                backend_kwargs=vector_backend_kwargs or {}
            )
        else:
            self.vector_memory = None

    def save_context(self, inputs: Dict[str, str], outputs: Dict[str, str]):
        self.buffer.save_context(inputs, outputs)

        if self.llm:
            new_lines = "\n".join(
                [f"Human: {v}" for k, v in inputs.items()] +
                [f"AI: {v}" for k, v in outputs.items()]
            )
            self.summary.update(new_lines, self.llm)
            self.entity.update(new_lines, self.llm)

    def load_memory(self) -> Dict[str, Any]:
        return {
            "history": self.buffer.get(),
            "summary": self.summary.get(),
            "entities": self.entity.all(),
        }

    def clear_all(self):
        self.buffer.clear()
        self.summary.clear()
        self.entity.clear()
        if hasattr(self.long_term, 'clear'):
            self.long_term.clear() 

    def is_ready(self) -> bool:
        ready = True
        if self.llm and not self.llm.is_ready():
            ready = False
        if self.vector_memory and not self.vector_memory.vector_store.is_ready():
            ready = False
        return ready 