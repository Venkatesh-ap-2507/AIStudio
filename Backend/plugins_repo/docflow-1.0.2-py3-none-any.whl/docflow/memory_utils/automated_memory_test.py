import unittest
from pydantic import ValidationError
from real_tests.mocks import MockLLM
from memory_utils import (
    SummaryMemory, EntityMemory, BufferMemory, MemoryManager, ShortTermMemory,
    METADATA_USER_ID, METADATA_TYPE
)

class TestMemoryUtils(unittest.TestCase):
    def test_short_term_memory(self):
        stm = ShortTermMemory()
        stm.set("foo", 123)
        self.assertEqual(stm.get("foo"), 123)
        stm.set("bar", 456)
        self.assertEqual(stm.get("bar"), 456)
        stm.clear()
        self.assertIsNone(stm.get("foo"))
        self.assertIsNone(stm.get("bar"))

    def test_buffer_memory(self):
        buf = BufferMemory(buffer_size=3)
        buf.save_context({"q": "hi"}, {"a": "hello"})
        buf.save_context({"q": "bye"}, {"a": "goodbye"})
        self.assertEqual(len(buf.get()), 2)
        buf.delete(0)
        self.assertEqual(len(buf.get()), 1)
        buf.clear()
        self.assertEqual(len(buf.get()), 0)

    def test_buffer_memory_batch(self):
        buf = BufferMemory(buffer_size=10)
        turns = [
            ({"user": "hi"}, {"ai": "hello"}),
            ({"user": "bye"}, {"ai": "goodbye"}),
            ({"user": "how are you?"}, {"ai": "I'm fine, thanks!"}),
        ]
        buf.save_context_batch(turns)
        self.assertEqual(len(buf.get()), 3)
        self.assertEqual(buf.get()[0]["inputs"], {"user": "hi"})
        self.assertEqual(buf.get()[1]["outputs"], {"ai": "goodbye"})
        self.assertEqual(buf.get()[2]["inputs"], {"user": "how are you?"})

    def test_buffer_memory_input_validation(self):
        buf = BufferMemory()
        with self.assertRaises(ValidationError):
            buf.save_context("not a dict", {})

    def test_summary_memory(self):
        sm = SummaryMemory()
        sm.set("This is a summary.")
        self.assertEqual(sm.get(), "This is a summary.")
        llm = MockLLM(response="Updated summary.")
        sm.update("New lines", llm)
        self.assertEqual(sm.get(), "Updated summary.")
        sm.clear()
        self.assertIsNone(sm.get())

    def test_summary_memory_input_validation(self):
        sm = SummaryMemory()
        with self.assertRaises(ValidationError):
            sm.set(123)

    def test_entity_memory(self):
        em = EntityMemory()
        em.set("person", "Aditya")
        self.assertEqual(em.get("person"), "Aditya")
        em.set("location", "Pune")
        self.assertEqual(em.get("location"), "Pune")
        self.assertEqual(em.all()["person"], "Aditya")
        em.clear()
        self.assertEqual(em.all(), {})

    def test_entity_memory_input_validation(self):
        em = EntityMemory()
        with self.assertRaises(ValidationError):
            em.set(123, "Aditya")

    def test_entity_memory_update(self):
        em = EntityMemory()
        llm = MockLLM(response='{"person": "Aditya", "location": "Pune"}')
        em.update("Human: Aditya\nAI: Hello Aditya!", llm)
        self.assertEqual(em.get("person"), "Aditya")
        self.assertEqual(em.get("location"), "Pune")

    def test_summary_memory_update_llm_required(self):
        sm = SummaryMemory()
        with self.assertRaises(ValueError):
            sm.update("test", None)

    def test_entity_memory_update_llm_required(self):
        em = EntityMemory()
        with self.assertRaises(ValueError):
            em.update("test", None)

    def test_llm_caching_and_clear(self):
        llm = MockLLM(response="cached!")
        prompt = "test prompt"
        result1 = llm.generate(prompt)
        self.assertEqual(result1, "cached!")
        llm.response = "should not see this"
        result2 = llm.generate(prompt)
        self.assertEqual(result2, "cached!")
        llm.clear_cache()
        result3 = llm.generate(prompt)
        self.assertEqual(result3, "should not see this")

    def test_memory_manager(self):
        llm = MockLLM(response="summary")
        mm = MemoryManager(llm=llm)
        mm.save_context({"q": "hi"}, {"a": "hello"})
        mem = mm.load_memory()
        self.assertIn("history", mem)
        self.assertIn("summary", mem)
        self.assertIn("entities", mem)
        mm.clear_all()
        mem2 = mm.load_memory()
        self.assertEqual(mem2["history"], [])
        self.assertIsNone(mem2["summary"])
        self.assertEqual(mem2["entities"], {})
        self.assertTrue(mm.is_ready())

    def test_metadata_constants(self):
        meta = {METADATA_USER_ID: "user123", METADATA_TYPE: "document"}
        self.assertEqual(meta[METADATA_USER_ID], "user123")
        self.assertEqual(meta[METADATA_TYPE], "document")

if __name__ == "__main__":
    unittest.main() 