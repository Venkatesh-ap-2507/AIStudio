from document_pipeline import process_file

process_file("demo.pdf") 
