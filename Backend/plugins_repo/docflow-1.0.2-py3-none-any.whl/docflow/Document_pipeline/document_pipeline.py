import os
import re
import logging
from typing import List, Protocol
import docx
import PyPDF2
import sqlite3
import pymongo
import snowflake.connector
import mysql.connector
import psycopg2
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("document_pipeline")

# ---------------------- File Reading ----------------------
def read_file(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    logger.info(f"Reading file: {file_path}")
    if ext == ".txt":
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    elif ext == ".pdf":
        with open(file_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            return "\n".join(page.extract_text() for page in reader.pages if page.extract_text())
    elif ext == ".docx":
        doc = docx.Document(file_path)
        return "\n".join(p.text for p in doc.paragraphs)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

# ---------------------- Cleaning ----------------------
def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()

# ---------------------- Chunking ----------------------
def chunk_text(text: str, max_tokens: int = 100) -> List[str]:
    sentences = re.split(r'(?<=[.?!]) +', text)
    chunks, current = [], ""
    for sentence in sentences:
        if len((current + sentence).split()) <= max_tokens:
            current += " " + sentence
        else:
            chunks.append(current.strip())
            current = sentence
    if current:
        chunks.append(current.strip())
    return chunks

# ---------------------- Embedding ----------------------
def embed_text(text: str) -> List[float]:
    response = client.embeddings.create(
        input=[text],
        model="text-embedding-3-small"
    )
    return response.data[0].embedding

# ---------------------- Vector Store Protocol ----------------------
class VectorStore(Protocol):
    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        ...

# ---------------------- Implementations ----------------------
class SQLiteVectorStore:
    def __init__(self, db_path="vectors.db"):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS vectors (id INTEGER PRIMARY KEY, chunk TEXT, embedding TEXT, metadata TEXT)"
        )

    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        for emb, meta in zip(embeddings, metadatas):
            self.conn.execute(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (?, ?, ?)",
                (meta["chunk"], str(emb), str(meta)),
            )
        self.conn.commit()

class MongoDBVectorStore:
    def __init__(self, uri="mongodb://localhost:27017", db_name="doc_db", collection_name="vectors"):
        self.client = pymongo.MongoClient(uri)
        self.collection = self.client[db_name][collection_name]

    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        docs = [{"embedding": emb, **meta} for emb, meta in zip(embeddings, metadatas)]
        self.collection.insert_many(docs)

class PostgresVectorStore:
    def __init__(self, host, user, password, dbname):
        self.conn = psycopg2.connect(host=host, user=user, password=password, dbname=dbname)
        with self.conn.cursor() as cur:
            cur.execute("""CREATE TABLE IF NOT EXISTS vectors (
                id SERIAL PRIMARY KEY,
                chunk TEXT,
                embedding TEXT,
                metadata TEXT
            )""")
            self.conn.commit()

    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        with self.conn.cursor() as cur:
            for emb, meta in zip(embeddings, metadatas):
                cur.execute(
                    "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                    (meta["chunk"], str(emb), str(meta)),
                )
            self.conn.commit()

class MySQLVectorStore:
    def __init__(self, host, user, password, database):
        self.conn = mysql.connector.connect(host=host, user=user, password=password, database=database)
        cur = self.conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS vectors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            chunk TEXT,
            embedding TEXT,
            metadata TEXT
        )""")
        self.conn.commit()

    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        cur = self.conn.cursor()
        for emb, meta in zip(embeddings, metadatas):
            cur.execute(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                (meta["chunk"], str(emb), str(meta)),
            )
        self.conn.commit()

class SnowflakeVectorStore:
    def __init__(self, user, password, account, warehouse, database, schema):
        self.conn = snowflake.connector.connect(
            user=user,
            password=password,
            account=account,
            warehouse=warehouse,
            database=database,
            schema=schema
        )
        cur = self.conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS vectors (
            id INTEGER AUTOINCREMENT,
            chunk STRING,
            embedding STRING,
            metadata STRING
        )""")

    def save(self, embeddings: List[List[float]], metadatas: List[dict]) -> None:
        cur = self.conn.cursor()
        for emb, meta in zip(embeddings, metadatas):
            cur.execute(
                "INSERT INTO vectors (chunk, embedding, metadata) VALUES (%s, %s, %s)",
                (meta["chunk"], str(emb), str(meta)),
            )

# ---------------------- Pipeline ----------------------
class DocumentPipeline:
    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store

    def run(self, file_path: str) -> None:
        try:
            text = read_file(file_path)
            cleaned = clean_text(text)
            chunks = chunk_text(cleaned)
            embeddings = [embed_text(chunk) for chunk in chunks]
            metadatas = [{"chunk": chunk, "chunk_index": i, "source": file_path} for i, chunk in enumerate(chunks)]
            self.vector_store.save(embeddings, metadatas)
            logger.info(f"Done. Stored {len(chunks)} chunks.")
        except Exception as e:
            logger.error(f"Pipeline failed: {e}")

# ---------------------- Main Wrapper ----------------------
def process_file(file_path: str, vector_store: VectorStore = None):
    supported_extensions = ['.txt', '.pdf', '.docx']
    ext = os.path.splitext(file_path)[1].lower()

    if ext not in supported_extensions:
        print(f"Unsupported file type: {ext}")
        return

    if not os.path.isfile(file_path):
        print(f"File not found: {file_path}")
        return

    if vector_store is None:
        vector_store = SQLiteVectorStore("default_vectors.db")

    pipeline = DocumentPipeline(vector_store=vector_store)
    pipeline.run(file_path)
