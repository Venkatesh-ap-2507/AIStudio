import os
import time
import logging
from typing import List, Optional, Dict, Any, Union
from dotenv import load_dotenv
from dataclasses import dataclass
import json
import traceback

load_dotenv()

def config_loader(key: str, default: Optional[Any] = None) -> Any:
    return os.getenv(key, default)

def get_logger(name: str = "embedder", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.hasHandlers():
        handler = logging.StreamHandler()
        formatter = logging.Formatter('[%(levelname)s] %(name)s: %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger

# Custom Exceptions
class EmbeddingError(Exception):
    pass

class InvalidConfigurationError(EmbeddingError):
    pass

class FileProcessingError(EmbeddingError):
    pass

# Import checks
try:
    import openai
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import cohere
    COHERE_AVAILABLE = True
except ImportError:
    COHERE_AVAILABLE = False

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False

@dataclass
class UserConfig:
    """User configuration for embedding parameters"""
    provider: str
    model: Optional[str] = None
    max_tokens_per_batch: int = 1000
    sentences_per_chunk: int = 3
    batch_size: int = 100
    
    def __post_init__(self):
        # Validate provider
        if self.provider.lower() not in ['openai', 'cohere', 'gemini']:
            raise InvalidConfigurationError(f"Unsupported provider: {self.provider}")
        
        self.provider = self.provider.lower()
        
        # Validate parameters
        if self.max_tokens_per_batch <= 0:
            raise InvalidConfigurationError("max_tokens_per_batch must be positive")
        if self.sentences_per_chunk <= 0:
            raise InvalidConfigurationError("sentences_per_chunk must be positive")

class Embedder:
    DEFAULT_MODELS = {
        'openai': 'text-embedding-3-small',
        'cohere': 'embed-english-v3.0',
        'gemini': 'models/embedding-001'
    }

    def __init__(self, user_config: UserConfig, api_key: Optional[str] = None):
        self.logger = get_logger()
        self.config = user_config
        self.api_key = api_key or self._get_api_key(user_config.provider)
        self.model = user_config.model or self.DEFAULT_MODELS.get(user_config.provider)
        
        self._validate_provider()
        self._client = self._initialize_client()
        
        self.logger.info(f"Initialized {self.config.provider} embedder with model: {self.model}")

    def _get_api_key(self, provider: str) -> str:
        """Get API key for the specified provider"""
        key = config_loader(f"{provider.upper()}_API_KEY")
        if not key:
            raise EmbeddingError(f"API key for provider '{provider}' not found. "
                               f"Please set {provider.upper()}_API_KEY environment variable.")
        return key

    def _validate_provider(self):
        """Validate provider availability"""
        if self.config.provider == 'openai' and not OPENAI_AVAILABLE:
            raise EmbeddingError("OpenAI package not installed. Install with: pip install openai")
        if self.config.provider == 'cohere' and not COHERE_AVAILABLE:
            raise EmbeddingError("Cohere package not installed. Install with: pip install cohere")
        if self.config.provider == 'gemini' and not GEMINI_AVAILABLE:
            raise EmbeddingError("Gemini package not installed. Install with: pip install google-generativeai")

    def _initialize_client(self):
        """Initialize the appropriate client based on provider"""
        if self.config.provider == 'openai':
            return OpenAI(api_key=self.api_key)
        elif self.config.provider == 'cohere':
            return cohere.Client(self.api_key)
        elif self.config.provider == 'gemini':
            genai.configure(api_key=self.api_key)
            return genai
        else:
            raise EmbeddingError(f"Cannot initialize client for {self.config.provider}")

    def process_uploaded_file(self, file_path: str, file_handler=None) -> Dict[str, Any]:
        """
        Process an uploaded file and generate embeddings
        
        Args:
            file_path: Path to the uploaded file
            file_handler: UniversalFileHandler instance (optional)
        
        Returns:
            Dict with embeddings, metadata, and processing info
        """
        try:
            # Import file handler if not provided
            if file_handler is None:
                from docflow.file_utils.file_handler import UniversalFileHandler
                file_handler = UniversalFileHandler()
            
            self.logger.info(f"Processing file: {file_path}")
            
            # Read file content using file handler
            file_data = file_handler.read_file(file_path)
            content = file_data["content"]
            metadata = file_data["metadata"]
            
            self.logger.info(f"File read successfully. Type: {metadata['filetype']}, Size: {metadata['size_kb']} KB")
            
            # Extract text content
            text_content = self._extract_text_content(content)
            
            if not text_content or not text_content.strip():
                raise FileProcessingError("No text content found in the file")
            
            # Chunk the text
            chunks = self._chunk_text(text_content)
            
            if not chunks:
                raise FileProcessingError("No chunks created from the text content")
            
            self.logger.info(f"Created {len(chunks)} chunks from the text")
            
            # Generate embeddings
            embeddings = self._generate_embeddings(chunks)
            
            # Prepare response
            response = {
                "status": "success",
                "file_metadata": metadata,
                "embeddings": embeddings,
                "chunks": chunks,
                "processing_info": {
                    "provider_used": self.config.provider,
                    "model_used": self.model,
                    "total_chunks": len(chunks),
                    "embedding_dimension": len(embeddings[0]) if embeddings else 0,
                    "total_tokens_estimated": sum(self._count_tokens(chunk) for chunk in chunks),
                    "configuration": {
                        "max_tokens_per_batch": self.config.max_tokens_per_batch,
                        "sentences_per_chunk": self.config.sentences_per_chunk,
                        "batch_size": self.config.batch_size
                    }
                }
            }
            
            self.logger.info(f"Successfully processed file with {len(embeddings)} embeddings")
            return response
            
        except Exception as e:
            error_response = {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__,
                "file_path": file_path,
                "traceback": traceback.format_exc()
            }
            self.logger.error(f"Error processing file {file_path}: {str(e)}")
            return error_response

    def _extract_text_content(self, content: Any) -> str:
        """Extract text content from various file types"""
        if isinstance(content, str):
            return content
        elif isinstance(content, list):
            return "\n".join(str(item) for item in content)
        elif isinstance(content, dict):
            return json.dumps(content, indent=2)
        else:
            return str(content)

    def _chunk_text(self, text: str) -> List[str]:
        """Chunk text based on user configuration"""
        return sentence_chunk(text, sentences_per_chunk=self.config.sentences_per_chunk)

    def _generate_embeddings(self, chunks: List[str]) -> List[List[float]]:
        """Generate embeddings for chunks"""
        self.logger.info(f"Generating embeddings for {len(chunks)} chunks")
        
        # Create batches based on token limits
        batches = self._token_based_batches(chunks, self.config.max_tokens_per_batch)
        results = []
        
        for i, batch in enumerate(batches):
            self.logger.info(f"Processing batch {i+1}/{len(batches)} with {len(batch)} chunks")
            
            if self.config.provider == 'openai':
                batch_results = self._embed_texts_openai(batch)
            elif self.config.provider == 'cohere':
                batch_results = self._embed_texts_cohere(batch)
            elif self.config.provider == 'gemini':
                batch_results = self._embed_texts_gemini(batch)
            
            results.extend(batch_results)
        
        return results

    def _embed_texts_openai(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using OpenAI"""
        results = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            response = self._client.embeddings.create(input=batch, model=self.model)
            results.extend([item.embedding for item in response.data])
        return results

    def _embed_texts_cohere(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using Cohere"""
        results = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            response = self._client.embed(texts=batch, model=self.model, input_type='search_document')
            results.extend(response.embeddings)
        return results

    def _embed_texts_gemini(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using Gemini"""
        results = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i:i + self.config.batch_size]
            embeddings = []
            for text in batch:
                response = self._client.embed_content(model=self.model, content=text)
                embeddings.append(response['embedding'])
            results.extend(embeddings)
        return results

    def _token_based_batches(self, texts: List[str], max_tokens: int) -> List[List[str]]:
        """Create batches based on token count"""
        batches = []
        current_batch = []
        current_tokens = 0
        
        for text in texts:
            tokens = self._count_tokens(text)
            if current_batch and current_tokens + tokens > max_tokens:
                batches.append(current_batch)
                current_batch = [text]
                current_tokens = tokens
            else:
                current_batch.append(text)
                current_tokens += tokens
        
        if current_batch:
            batches.append(current_batch)
        
        return batches

    def _count_tokens(self, text: str) -> int:
        """Count tokens in text"""
        if TIKTOKEN_AVAILABLE:
            try:
                enc = tiktoken.get_encoding('cl100k_base')
                return len(enc.encode(text))
            except Exception:
                pass
        # Fallback to word count approximation
        return len(text.split())


# Utility functions
def sentence_chunk(text: str, sentences_per_chunk: int = 3) -> List[str]:
    """Chunk text by sentences"""
    import re
    if not text or not isinstance(text, str):
        return []
    
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    
    chunks = []
    for i in range(0, len(sentences), sentences_per_chunk):
        chunk = " ".join(sentences[i:i + sentences_per_chunk])
        chunks.append(chunk)
    
    return chunks


def create_embedder_from_config(config_dict: Dict[str, Any], api_key: Optional[str] = None) -> Embedder:
    """Create embedder from configuration dictionary"""
    user_config = UserConfig(**config_dict)
    return Embedder(user_config, api_key)


def process_file_with_embeddings(
    file_path: str, 
    config: Dict[str, Any], 
    api_key: Optional[str] = None,
    file_handler=None
) -> Dict[str, Any]:
    """
    Main function to process uploaded file and generate embeddings
    
    Args:
        file_path: Path to the uploaded file
        config: User configuration dict with provider, model, token limits, etc.
        api_key: Optional API key
        file_handler: Optional file handler instance
    
    Returns:
        Dict with embeddings and processing info
    """
    embedder = create_embedder_from_config(config, api_key)
    return embedder.process_uploaded_file(file_path, file_handler)


# Backward compatibility
def embed_texts(texts: Union[str, List[str]], provider: str = "openai", **kwargs) -> List[List[float]]:
    """Generate embeddings for texts (backward compatibility)"""
    config = {
        "provider": provider,
        **kwargs
    }
    embedder = create_embedder_from_config(config)
    
    if isinstance(texts, str):
        texts = [texts]
    
    return embedder._generate_embeddings(texts)


def create_embedder(provider: str = "openai", **kwargs) -> Embedder:
    """Create embedder (backward compatibility)"""
    config = {"provider": provider, **kwargs}
    return create_embedder_from_config(config)


