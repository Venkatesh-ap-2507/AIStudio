from docchain.Embedding_utils.embedding import embedder_demo

if __name__ == "__main__":
    params = {
        "doc_path": "Document_template.docx",   
        "provider": "Huggingface",                     
        "model": "sentence-transformer",       
        "output_path": "test_output.txt",         
        "sentences_per_chunk": 3                 
    }
    embedder_demo(**params)
