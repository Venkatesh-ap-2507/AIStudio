import logging
import json
import os
import queue
import sys
from datetime import datetime
from logging.handlers import QueueHandler, RotatingFileHandler
from typing import Optional, Dict, Any

# Database clients
from pymongo import MongoClient
import psycopg2
from psycopg2 import OperationalError, DatabaseError as PostgresError
from neo4j import GraphDatabase
from neo4j.exceptions import Neo4jError
import snowflake.connector
from snowflake.connector.errors import DatabaseError as SnowflakeError


class JsonFormatter(logging.Formatter):
    def __init__(self, json_formatter_func):
        super().__init__()
        self.json_formatter_func = json_formatter_func

    def format(self, record: logging.LogRecord) -> str:
        return self.json_formatter_func(record)


class UniversalLogger:
    def __init__(
        self,
        name: str,
        log_file: str = "app.log",
        log_level: str = "INFO",
        max_file_size: int = 5 * 1024 * 1024,
        backup_count: int = 3,
        log_format: str = "json",
        console_output: bool = True,
        async_safe: bool = True
    ):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
        self.logger.propagate = False  # Prevent duplicate logs

        if not self.logger.handlers:
            formatter = JsonFormatter(self._json_formatter) if log_format == "json" else \
                logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

            handlers = []
            if console_output:
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(formatter)
                handlers.append(console_handler)

            file_handler = RotatingFileHandler(log_file, maxBytes=max_file_size, backupCount=backup_count)
            file_handler.setFormatter(formatter)
            handlers.append(file_handler)

            if async_safe:
                log_queue = queue.Queue(-1)
                queue_handler = QueueHandler(log_queue)
                queue_listener = logging.handlers.QueueListener(log_queue, *handlers, respect_handler_level=True)
                queue_listener.start()
                self.logger.addHandler(queue_handler)
                self.queue_listener = queue_listener
            else:
                for handler in handlers:
                    self.logger.addHandler(handler)

    def _json_formatter(self, record: logging.LogRecord) -> str:
        # Always-included fields
        log_record = {
            "timestamp": datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
            "filename": record.filename,
            "lineno": record.lineno,
            "thread": record.threadName,
            "process": record.process
        }
        # Add any extra fields (user_id, action, request_id, etc.) if present
        if hasattr(record, 'extra'):
            log_record.update(record.extra)
        if record.exc_info:
            import traceback
            log_record["traceback"] = "".join(traceback.format_exception(*record.exc_info))
        return json.dumps(log_record)

    def log(self, level: str, message: str, extra: Optional[Dict[str, Any]] = None):
        try:
            self.logger.log(getattr(logging, level.upper(), logging.INFO), message, extra=extra)
        except Exception as e:
            print(f"[Logger Error] {e}")

    def debug(self, message, extra=None):
        self.log("DEBUG", message, extra=extra)

    def info(self, message, extra=None):
        self.log("INFO", message, extra=extra)

    def warning(self, message, extra=None):
        self.log("WARNING", message, extra=extra)

    def error(self, message, extra=None):
        self.log("ERROR", message, extra=extra)

    def critical(self, message, extra=None):
        self.log("CRITICAL", message, extra=extra)

    def exception(self, message, extra=None):
        self.logger.log(logging.ERROR, message, extra=extra, exc_info=True)

    def add_db_handler(self, db_type: str, config: dict, table_or_collection: str = "logs"):
        db_type = db_type.lower()
        handler = None

        try:
            if db_type == "mongodb":
                client = MongoClient(config["uri"])
                collection = client[config["database"]][table_or_collection]

                class MongoHandler(logging.Handler):
                    def emit(self, record):
                        try:
                            log_entry = self.format(record)
                            collection.insert_one(json.loads(log_entry))
                        except Exception as e:
                            print(f"[MongoDB Error] {e}")

                handler = MongoHandler()

            elif db_type == "postgresql":
                conn = psycopg2.connect(**config)
                cursor = conn.cursor()
                cursor.execute(f"""
                    CREATE TABLE IF NOT EXISTS {table_or_collection} (
                        id SERIAL PRIMARY KEY,
                        log_data JSONB
                    )
                """)
                conn.commit()

                class PostgresHandler(logging.Handler):
                    def emit(self, record):
                        try:
                            log_entry = self.format(record)
                            cursor.execute(f"INSERT INTO {table_or_collection} (log_data) VALUES (%s)", [log_entry])
                            conn.commit()
                        except Exception as e:
                            print(f"[PostgreSQL Error] {e}")

                handler = PostgresHandler()

            elif db_type == "neo4j":
                driver = GraphDatabase.driver(config["uri"], auth=(config["username"], config["password"]))

                class Neo4jHandler(logging.Handler):
                    def emit(self, record):
                        try:
                            log_entry = self.format(record)
                            with driver.session() as session:
                                session.run(f"CREATE (l:{table_or_collection} {{log_data: $log_data}})", log_data=log_entry)
                        except Exception as e:
                            print(f"[Neo4j Error] {e}")

                handler = Neo4jHandler()

            elif db_type == "snowflake":
                conn = snowflake.connector.connect(**config)
                cursor = conn.cursor()
                cursor.execute(f"""
                    CREATE TABLE IF NOT EXISTS {table_or_collection} (
                        id INTEGER AUTOINCREMENT,
                        log_data STRING
                    )
                """)

                class SnowflakeHandler(logging.Handler):
                    def emit(self, record):
                        try:
                            log_entry = self.format(record)
                            cursor.execute(f"INSERT INTO {table_or_collection} (log_data) VALUES (%s)", (log_entry,))
                        except Exception as e:
                            print(f"[Snowflake Error] {e}")

                handler = SnowflakeHandler()

            else:
                print(f"[Error] Unsupported DB type: {db_type}")
                return

            handler.setFormatter(JsonFormatter(self._json_formatter))
            if hasattr(self, 'queue_listener'):
                self.queue_listener.handlers += (handler,)
            else:
                self.logger.addHandler(handler)

            print(f"[Success] {db_type.capitalize()} handler added successfully")

        except Exception as e:
            print(f"[Handler Setup Error for {db_type}] {e}")

    def get_real_handlers(self):
        if hasattr(self, 'queue_listener'):
            return list(self.queue_listener.handlers)
        else:
            return self.logger.handlers


def auto_log_exceptions(logger):
    """
    Sets a global exception hook to automatically log all uncaught exceptions using the provided UniversalLogger.
    Usage: auto_log_exceptions(logger)
    """
    import sys
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.logger.error(
            f"Uncaught exception: {exc_value}",
            exc_info=(exc_type, exc_value, exc_traceback)
        )
    sys.excepthook = handle_exception


def auto_log_function(logger, level="INFO"):
    """
    Decorator to automatically log function entry, exit, and exceptions using the provided UniversalLogger.
    Usage:
        @auto_log_function(logger)
        def my_func(...): ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            print("Decorator wrapper called")
            logger.log(level, f"Calling {func.__name__}", extra={"function_args": args, "function_kwargs": kwargs})
            try:
                result = func(*args, **kwargs)
                logger.log(level, f"{func.__name__} returned", extra={"result": result})
                return result
            except Exception as e:
                print(f"Decorator caught exception: {e}")
                logger.exception(f"Exception in {func.__name__}: {e}")
                for handler in logger.logger.handlers:
                    if hasattr(handler, 'flush'):
                        handler.flush()
                if hasattr(logger, 'queue_listener'):
                    logger.queue_listener.stop()
                raise
        return wrapper
    return decorator


def auto_log_standard(logger):
    """
    Attaches UniversalLogger's real handlers to the root logger, automatically capturing all standard logging calls.
    Usage: auto_log_standard(logger)
    """
    import logging
    root_logger = logging.getLogger()
    for handler in logger.get_real_handlers():
        if handler not in root_logger.handlers:
            root_logger.addHandler(handler)


def auto_log_flask(app, logger):
    """
    Adds middleware to a Flask app to automatically log HTTP requests, responses, and errors using UniversalLogger.
    Usage: auto_log_flask(app, logger)
    """
    from flask import request
    @app.before_request
    def log_request():
        logger.info("HTTP Request", extra={
            "path": request.path,
            "method": request.method,
            "query_args": request.args.to_dict(),
            "remote_addr": request.remote_addr
        })
    @app.after_request
    def log_response(response):
        logger.info("HTTP Response", extra={
            "status": response.status,
            "headers": dict(response.headers)
        })
        return response
    @app.teardown_request
    def log_exception(exc):
        if exc:
            logger.exception("HTTP Exception", extra={"exception": str(exc)})


def auto_log_fastapi(app, logger):
    """
    Adds middleware to a FastAPI app to automatically log HTTP requests, responses, and errors using UniversalLogger.
    Usage:
        from logging_utils import auto_log_fastapi
        auto_log_fastapi(app, logger)
    """
    from fastapi import Request
    from starlette.middleware.base import BaseHTTPMiddleware
    import time

    class LoggingMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            logger.info("HTTP Request", extra={
                "path": request.url.path,
                "method": request.method,
                "query_params": dict(request.query_params),
                "client": request.client.host if request.client else None
            })
            start_time = time.time()
            try:
                response = await call_next(request)
            except Exception as exc:
                logger.exception("HTTP Exception", extra={"exception": str(exc)})
                raise
            process_time = time.time() - start_time
            logger.info("HTTP Response", extra={
                "status": response.status_code,
                "headers": dict(response.headers),
                "process_time": process_time
            })
            return response

    app.add_middleware(LoggingMiddleware) 