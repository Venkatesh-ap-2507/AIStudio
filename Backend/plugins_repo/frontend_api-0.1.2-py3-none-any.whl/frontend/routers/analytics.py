from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any

router = APIRouter(prefix="/analytics", tags=["Analytics"])

class AnalyticsResponse(BaseModel):
    total_queries: int
    avg_response_time: float
    popular_topics: list

@router.get("/stats", response_model=AnalyticsResponse)
def get_analytics():
    return AnalyticsResponse(
        total_queries=1250,
        avg_response_time=0.85,
        popular_topics=["AI", "FastAPI", "Python"]
    )

@router.get("/health")
def health_check():
    return {"status": "healthy", "uptime": "24h"}