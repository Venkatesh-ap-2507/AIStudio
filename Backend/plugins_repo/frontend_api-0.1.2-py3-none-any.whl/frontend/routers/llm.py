from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, Any, Callable

router = APIRouter(prefix="/llm", tags=["LLM Operations"])

class QueryRequest(BaseModel):
    query: str = Field(..., description="User's question")
    metadata: Dict[str, Any] = Field(default_factory=dict)

class LLMResponse(BaseModel):
    response: str

# Store handler reference
_llm_handler: Callable[[str, Dict[str, Any]], str] = None

def set_llm_handler(handler: Callable[[str, Dict[str, Any]], str]):
    global _llm_handler
    _llm_handler = handler

@router.post("/ask", response_model=LLMResponse)
def ask_llm(data: QueryRequest):
    if not data.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty.")
    try:
        response = _llm_handler(data.query, data.metadata)
        return LLMResponse(response=response)
    except Exception:
        raise HTTPException(status_code=500, detail="LLM processing failed.")

@router.get("/models")
def list_models():
    return {"models": ["gpt-4", "claude-3", "local-model"]}