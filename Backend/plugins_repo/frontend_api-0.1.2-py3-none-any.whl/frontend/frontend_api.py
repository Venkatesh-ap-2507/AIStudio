from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
from typing import Callable, Dict, Any, Optional
import importlib.resources

from .routers import llm, documents, analytics

class FrontendUtilsAPI:
    def __init__(
        self,
        llm_handler: Callable[[str, Dict[str, Any]], str],
        info_handler: Optional[Callable[[str, Dict[str, Any]], str]] = None,
        allow_origins: list = ["*"]
    ):
        self.llm_handler = llm_handler
        self.info_handler = info_handler or self.default_info_handler
        self.allow_origins = allow_origins
        self.app = self._create_app()

    def _create_app(self) -> FastAPI:
        app = FastAPI(
            title="Multi-Endpoint API",
            description="FastAPI with multiple organized endpoints",
            version="1.0.0"
        )

        # CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.allow_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Set handlers for routers
        llm.set_llm_handler(self.llm_handler)

        # Include routers
        app.include_router(llm.router)
        app.include_router(documents.router)
        app.include_router(analytics.router)

        # Mount static files for /static
        try:
            static_dir = importlib.resources.files("frontend").joinpath("static")
            app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
        except:
            pass  # Static directory might not exist or not accessible

        # Exception handlers
        self._add_exception_handlers(app)

        # Root endpoint serving index.html
        @app.get("/", response_class=HTMLResponse)
        def root():
            try:
                content = importlib.resources.files("frontend").joinpath("static/index.html").read_text()
                return HTMLResponse(content=content, status_code=200)
            except FileNotFoundError:
                return JSONResponse(
                    status_code=404,
                    content={"error": "index.html not found"}
                )

        return app

    def _add_exception_handlers(self, app: FastAPI):
        @app.exception_handler(HTTPException)
        async def http_exception_handler(request: Request, exc: HTTPException):
            return JSONResponse(
                status_code=exc.status_code,
                content={"error": "HTTP Error", "details": exc.detail}
            )

        @app.exception_handler(ValidationError)
        async def validation_exception_handler(request: Request, exc: ValidationError):
            return JSONResponse(
                status_code=422,
                content={"error": "Validation Failed", "details": exc.errors()}
            )

    def get_app(self) -> FastAPI:
        return self.app

    @staticmethod
    def default_info_handler(context: str, metadata: Dict[str, Any]) -> str:
        return f"Info received: {context}"
